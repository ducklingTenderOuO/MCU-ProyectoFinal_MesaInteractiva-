const int MUX_S0 = A1; 
const int MUX_S1 = A2; 
const int MUX_S2 = A3; 

const int sensorPin = A0; 

void setup() {
  Serial.begin(9600);
  
  pinMode(MUX_S0, OUTPUT);
  pinMode(MUX_S1, OUTPUT);
  pinMode(MUX_S2, OUTPUT);
  
  Serial.println("Prueba de Sensores IR (Multiplexor) iniciada...");
}

void loop() {
  for (int canal = 0; canal < 8; canal++) {
    
    digitalWrite(MUX_S0, bitRead(canal, 0));
    digitalWrite(MUX_S1, bitRead(canal, 1));
    digitalWrite(MUX_S2, bitRead(canal, 2));
    
    delay(2);
    
    int valorIR = analogRead(sensorPin);
    
    // Imprimir el valor del sensor
    Serial.print("S");
    Serial.print(canal);
    Serial.print(": ");
    Serial.print(valorIR);
    Serial.print("\t"); // Espacio tabulado
  }
  
  Serial.println(); 
  delay(300);       
}
