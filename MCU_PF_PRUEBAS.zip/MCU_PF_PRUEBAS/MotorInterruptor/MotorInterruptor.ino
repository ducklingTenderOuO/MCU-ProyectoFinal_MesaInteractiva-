int motorPin = 11; // Pin conectado a la base del TIP41

void setup() {
  pinMode(motorPin, OUTPUT);
  digitalWrite(motorPin, LOW); // Apagamos el motor al inicio
}

void loop() {
  // Encender motor por 2 segundos
  digitalWrite(motorPin, HIGH); // HIGH en NPN = motor encendido
  delay(2000);

  // Apagar motor por 2 segundos
  digitalWrite(motorPin, LOW); // LOW en NPN = motor apagado
  delay(2000);
}