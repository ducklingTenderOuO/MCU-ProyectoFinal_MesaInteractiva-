#include <Keypad.h>
#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>

// RX en Pin 13 (conectado al TX del DFPlayer)
// TX en Pin 12 (conectado al RX del DFPlayer)
SoftwareSerial mySoftwareSerial(13, 12); 
DFRobotDFPlayerMini myDFPlayer;

const byte ROWS = 4; 
const byte COLS = 4; 
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte rowPins[ROWS] = {2, 3, 4, 5}; 
byte colPins[COLS] = {6, 7, 8, 9}; 
Keypad keypad = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

void setup() {
  Serial.begin(9600);
  mySoftwareSerial.begin(9600); // Velocidad que usa el DFPlayer
  
  Serial.println("Inicializando DFPlayer... (Puede tardar 3 segundos)");
  
  // Iniciar DFPlayer
  if (!myDFPlayer.begin(mySoftwareSerial, true, true)) {
    Serial.println("Error: Revisa conexiones RX/TX o la SD no esta puesta.");
    while(true); // Se queda aquí si hay error
  }
  
  Serial.println("DFPlayer listo!");
  myDFPlayer.volume(10);  // Volumen BAJO (es de 0 a 30)
}

void loop() {
  char key = keypad.getKey();
  
  if (key) {
    Serial.print("Boton: ");
    Serial.println(key);
    
    if (key >= '1' && key <= '9') {
      int track = key - '0';
      // Reproduce la cancion de la carpeta "01"
      myDFPlayer.playFolder(1, track); 
      Serial.print("Mandando orden al DFPlayer: Carpeta 1, Pista ");
      Serial.println(track);
    }
    else if (key == '*') {
      myDFPlayer.volumeDown();
      Serial.println("Volumen bajado 1 nivel");
    }
    else if (key == '#') {
      myDFPlayer.volumeUp();
      Serial.println("Volumen subido 1 nivel");
    }
    else if (key == '0') {
      myDFPlayer.pause();
      Serial.println("Pausa");
    }
  }
}
