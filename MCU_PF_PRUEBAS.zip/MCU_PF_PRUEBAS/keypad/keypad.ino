#include <Keypad.h>

const byte ROWS = 4; 
const byte COLS = 4; 

// Mapa de teclas del teclado 4x4
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

// Conexiones:
// Filas 1, 2, 3, 4 a los pines 2, 3, 4, 5
byte rowPins[ROWS] = {2, 3, 4, 5}; 
// Columnas 1, 2, 3, 4 a los pines 6, 7, 8, 9
byte colPins[COLS] = {6, 7, 8, 9}; 

Keypad keypad = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

void setup(){
  Serial.begin(9600);
  Serial.println("Prueba de teclado iniciada...");
}
  
void loop(){
  char key = keypad.getKey();
  
  if (key){
    Serial.print("Boton presionado: ");
    Serial.println(key);
  }
}
